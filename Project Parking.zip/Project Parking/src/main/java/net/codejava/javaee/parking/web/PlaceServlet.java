package net.codejava.javaee.parking.web;


import service.PlaceService;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import net.codejava.javaee.parking.model.Place;

/**
 * Servlet implementation class PlaceController
 */
public class PlaceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private PlaceService ss = new PlaceService();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public PlaceServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("op") != null) {
			if (request.getParameter("op").equals("load")) {
				response.setContentType("application/json");
				List<Place> places = ss.findAll();
				Gson json = new Gson();
				response.getWriter().write(json.toJson(places));

			} else if (request.getParameter("op").equals("delete")) {
				int id = Integer.parseInt(request.getParameter("id"));
				ss.delete(ss.findById(id));
				response.setContentType("application/json");
				List<Place> places = ss.findAll();
				Gson json = new Gson();
				response.getWriter().write(json.toJson(places));

			} else if (request.getParameter("op").equals("update")) {
				int id = Integer.parseInt(request.getParameter("id"));
				int numero = Integer.parseInt(request.getParameter("numero"));
				String etat = request.getParameter("etat");
				String type = request.getParameter("type");
				int section = Integer.parseInt(request.getParameter("section"));
				Place place = new Place(id, numero, etat, type, section);
				ss.update(place);
				response.setContentType("application/json");
				List<Place> places = ss.findAll();
				Gson json = new Gson();
				response.getWriter().write(json.toJson(places));
			}
		} else {
			int numero = Integer.parseInt(request.getParameter("numero"));
			String etat = request.getParameter("etat");
			String type = request.getParameter("type");
			int section = Integer.parseInt(request.getParameter("section"));
			ss.create(new Place(numero, etat, type, section));
			response.setContentType("application/json");
			List<Place> places = ss.findAll();
			Gson json = new Gson();
			response.getWriter().write(json.toJson(places));
			response.sendRedirect("place.jsp");
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		processRequest(request, response);
	}

}
