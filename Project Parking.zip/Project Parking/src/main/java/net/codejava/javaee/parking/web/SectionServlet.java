package net.codejava.javaee.parking.web;


import service.SectionService;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import net.codejava.javaee.parking.model.Section;

/**
 * Servlet implementation class SectionController
 */
public class SectionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private SectionService ss = new SectionService();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SectionServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("op") != null) {
			if (request.getParameter("op").equals("load")) {
				response.setContentType("application/json");
				List<Section> Sections = ss.findAll();
				Gson json = new Gson();
				response.getWriter().write(json.toJson(Sections));

			} else if (request.getParameter("op").equals("delete")) {
				int id = Integer.parseInt(request.getParameter("id"));
				ss.delete(ss.findById(id));
				response.setContentType("application/json");
				List<Section> Sections = ss.findAll();
				Gson json = new Gson();
				response.getWriter().write(json.toJson(Sections));

			} else if (request.getParameter("op").equals("update")) {
				int id = Integer.parseInt(request.getParameter("id"));
				String code = request.getParameter("code");
				Section section = new Section(id, code);
				ss.update(section);
				response.setContentType("application/json");
				List<Section> Sections = ss.findAll();
				Gson json = new Gson();
				response.getWriter().write(json.toJson(Sections));
			}

		} else {
			String code = request.getParameter("code");
			boolean existe = ss.findByCode(code);

			if (!(existe)) {
				ss.create(new Section(code));
			}
			response.setContentType("application/json");
			List<Section> Sections = ss.findAll();
			Gson json = new Gson();
			response.getWriter().write(json.toJson(Sections));

			response.sendRedirect("section.jsp");
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		processRequest(request, response);
	}

}
