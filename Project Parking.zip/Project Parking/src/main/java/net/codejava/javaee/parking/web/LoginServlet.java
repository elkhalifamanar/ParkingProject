package net.codejava.javaee.parking.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import entities.Message;
import net.codejava.javaee.parking.model.LoginBean;


import service.LoginService;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LoginServlet() {
		super();
// TODO Auto-generated constructor stub
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("Username");
		String password = request.getParameter("Password");

		LoginBean login = new LoginBean();
		login.setUsername(username);
		login.setPassword(password);

		LoginService ls = new LoginService();
		if (ls.validate(login)) {
			response.sendRedirect("index.jsp");
		} else {
			//Message message = new Message("Compte n'existe pas!", "error", "danger");
			//HttpSession s = request.getSession();
			//s.setAttribute("msg", message);
			response.sendRedirect("login.jsp");
		}
//PrintWriter out = response.getWriter();
//out.println("vous etes: " + username + " " + password);
//System.out.println(username + "/" + password);
//doGet(request, response);
//doGet(request, response);
	}

}