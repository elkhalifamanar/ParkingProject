package net.codejava.javaee.parking.model;


public class Section {
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	private int id;
	private String code;

	public Section(int id, String code) {
		super();
		this.id = id;
		this.code = code;
	}

	public Section(String code) {
		super();
		this.code = code;
	}

}
